class Main {
  public static void main(String[] args) {
    GameRunner.main(args);
  }
}

//links for things
// game variants - https://www.youtube.com/watch?v=vcgjkcCbZzc
// blimp image - http://clipart-library.com/blimp-cliparts.html